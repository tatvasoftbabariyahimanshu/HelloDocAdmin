﻿namespace HMS.Repositories
{
    public class Class1
    {

    }
}