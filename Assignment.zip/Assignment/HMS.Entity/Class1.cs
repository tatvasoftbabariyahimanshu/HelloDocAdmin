﻿namespace HMS.Entity
{
    public class Class1
    {

    }
}