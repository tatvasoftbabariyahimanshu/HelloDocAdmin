﻿namespace HMS.Entity.ViewModels
{
    public class Constant
    {
        public enum Gender
        {
            male = 1,
            female,
            other,

        }




    }
}
